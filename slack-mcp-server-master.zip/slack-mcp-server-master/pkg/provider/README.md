The "edge" package has been partially copied from `rusq/slackdump`.

Credits to the https://github.com/rusq.
